# معيض موتور — Firebase + Gemini

مشروع Android Kotlin/Compose مرتبط بمشروع Firebase عبر `google-services.json`.

## المزايا المجهزة
- Firestore للإعلانات والإعدادات.
- Firebase Authentication بتسجيل مجهول لإنشاء مستخدم آمن عند النشر.
- Firebase Storage جاهز لقواعد تخزين صور الإعلانات.
- Firebase AI Logic + Gemini للمساعد الذكي، بدون وضع مفتاح Gemini داخل التطبيق.
- نشر إعلان جديد من داخل السوق.
- رقم التواصل: 771335364.
- حقول روابط المحافظ اختيارية.

## إعداد Firebase المطلوب قبل أول تشغيل فعلي
1. فعّل Authentication > Sign-in method > Anonymous.
2. في Firebase Console افتح AI Services > AI Logic > Get started واختر Gemini Developer API. Firebase توصي بهذا المسار للبدء بدون إعداد billing لواجهة Agent Platform.
3. عند فرض App Check، فعّل Debug provider أثناء التطوير ثم استخدم مزود attestation للإصدار النهائي.
4. انشر `firestore.rules` و`storage.rules` إلى Firebase.
5. افتح المشروع في Android Studio وانتظر Gradle Sync ثم Run.

لا تضع مفاتيح سرية إضافية داخل الكود.
