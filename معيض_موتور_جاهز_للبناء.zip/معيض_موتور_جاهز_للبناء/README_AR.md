# معيض موتور — النسخة الجاهزة للبناء

هذه نسخة مشروع Android النهائية التي تم إعدادها للتطبيق، مع ملف Firebase المرتبط بالمشروع.

## معلومات التطبيق
- الاسم: معيض موتور
- Package: `com.maayed.motor`
- Firebase: متصل عبر `app/google-services.json`
- رقم التواصل: `771335364`

## لإخراج APK
افتح مجلد المشروع في Android Studio/بيئة بناء Android، ثم نفّذ:

`./gradlew assembleDebug`

ملف APK الناتج يكون عادة داخل:

`app/build/outputs/apk/debug/app-debug.apk`

> هذه الحزمة هي مصدر التطبيق وليست ملف APK بحد ذاته. لا يمكن إنشاء APK داخل هذه المحادثة لأن بيئة التشغيل الحالية لا تحتوي Android SDK/Gradle اللازمة لبناء تطبيق Android.
