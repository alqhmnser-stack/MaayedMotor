package com.maayed.motor

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.GenerativeBackend
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

private data class Listing(
    val id: String = "",
    val name: String = "",
    val price: String = "",
    val category: String = "أخرى",
    val seller: String = "مستخدم",
    val phone: String = "",
    val description: String = "",
    val imageUrl: String = ""
)

private val demoBikes = listOf(
    Listing("demo1", "دراجة نارية 150cc", "1,250,000 ريال", "دراجات", "معرض معيض"),
    Listing("demo2", "دراجة 200cc رياضية", "1,850,000 ريال", "دراجات", "أبو محمد"),
    Listing("demo3", "محرك 125cc", "450,000 ريال", "محركات", "معيض موتور"),
    Listing("demo4", "طقم فرامل أصلي", "35,000 ريال", "قطع غيار", "قطع معيض"),
    Listing("demo5", "خوذة احترافية", "28,000 ريال", "إكسسوارات", "موتور شوب")
)

private val db get() = FirebaseFirestore.getInstance()
private val auth get() = FirebaseAuth.getInstance()
private val storage get() = FirebaseStorage.getInstance()

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App() {
    var page by remember { mutableIntStateOf(0) }
    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF111827))) {
        Scaffold(bottomBar = {
            NavigationBar {
                listOf("الرئيسية", "السوق", "المساعد", "حسابي").forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = page == i,
                        onClick = { page = i },
                        icon = { Text(listOf("⌂", "🏍", "✦", "●")[i]) },
                        label = { Text(t) }
                    )
                }
            }
        }) { p ->
            Box(Modifier.padding(p).fillMaxSize()) {
                when (page) {
                    0 -> Home({ page = 1 }, { page = 2 })
                    1 -> Market()
                    2 -> Assistant()
                    else -> Account()
                }
            }
        }
    }
}

@Composable
fun Header() {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp)) {
        Text("معيض موتور", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("منصة الدراجات النارية", color = MaterialTheme.colorScheme.primary.copy(alpha = .65f))
    }
}

@Composable
fun Home(goMarket: () -> Unit, goAI: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize()) {
        item { Header() }
        item {
            Card(Modifier.padding(horizontal = 16.dp).fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(20.dp)) {
                    Text("كل ما يخص الدراجات في مكان واحد", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("بيع وشراء • قطع غيار • صيانة • استشارات ذكية")
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = goMarket) { Text("تصفح السوق") }
                        OutlinedButton(onClick = goAI) { Text("اسأل المساعد") }
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
        }
        item { Text("الأقسام", fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(20.dp, 4.dp)) }
        item {
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf("🏍️\nدراجات", "🔧\nصيانة", "⚙️\nقطع غيار").forEach {
                    Box(Modifier.weight(1f).height(90.dp).background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
                        Text(it, textAlign = TextAlign.Center, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
        }
        item { Text("إعلانات مميزة", fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(20.dp, 4.dp)) }
        items(demoBikes.take(3)) { ListingCard(it) }
    }
}

@Composable
fun Market() {
    var query by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("الكل") }
    var listings by remember { mutableStateOf(demoBikes) }
    var showAdd by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }

    DisposableEffect(Unit) {
        val registration = db.collection("listings").limit(100).addSnapshotListener { snap, err ->
            if (err != null) { message = "تعذر تحميل الإعلانات: ${err.localizedMessage}"; return@addSnapshotListener }
            if (snap != null) {
                val live = snap.documents.mapNotNull { d ->
                    d.toObject(Listing::class.java)?.copy(id = d.id)
                }
                if (live.isNotEmpty()) listings = live
            }
        }
        onDispose { registration.remove() }
    }

    val filtered = listings.filter { (cat == "الكل" || it.category == cat) && (query.isBlank() || it.name.contains(query, true)) }
    Column(Modifier.fillMaxSize()) {
        Header()
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(query, { query = it }, modifier = Modifier.weight(1f), label = { Text("بحث") }, singleLine = true)
            Button(onClick = { showAdd = true }) { Text("＋") }
        }
        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            listOf("الكل", "دراجات", "قطع غيار", "إكسسوارات", "محركات").forEach { x ->
                FilterChip(selected = cat == x, onClick = { cat = x }, label = { Text(x) })
            }
        }
        if (message.isNotBlank()) Text(message, Modifier.padding(horizontal = 16.dp))
        LazyColumn { items(filtered) { ListingCard(it) } }
    }
    if (showAdd) AddListingDialog(onDismiss = { showAdd = false }, onSaved = { showAdd = false })
}

@Composable
fun ListingCard(b: Listing) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(82.dp).background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) { Text("🏍️", fontSize = 35.sp) }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(b.name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(b.category)
                Text(b.price, fontWeight = FontWeight.Bold)
                Text("البائع: ${b.seller}", fontSize = 12.sp)
                if (b.phone.isNotBlank()) Text("📞 ${b.phone}", fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun AddListingDialog(onDismiss: () -> Unit, onSaved: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("دراجات") }
    var phone by remember { mutableStateOf("771335364") }
    var description by remember { mutableStateOf("") }
    var saving by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("نشر إعلان") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("اسم المنتج") }, singleLine = true)
                OutlinedTextField(price, { price = it }, label = { Text("السعر") }, singleLine = true)
                OutlinedTextField(category, { category = it }, label = { Text("القسم") }, singleLine = true)
                OutlinedTextField(phone, { phone = it }, label = { Text("رقم التواصل") }, singleLine = true)
                OutlinedTextField(description, { description = it }, label = { Text("الوصف") }, minLines = 2)
            }
        },
        confirmButton = {
            Button(enabled = !saving && name.isNotBlank(), onClick = {
                saving = true
                scope.launch {
                    try {
                        if (auth.currentUser == null) auth.signInAnonymously().await()
                        db.collection("listings").add(
                            mapOf("name" to name, "price" to price, "category" to category, "seller" to "معيض موتور", "phone" to phone, "description" to description, "createdAt" to System.currentTimeMillis())
                        ).await()
                        onSaved()
                    } catch (_: Exception) { saving = false }
                }
            }) { Text(if (saving) "جارٍ الحفظ…" else "نشر") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
fun Assistant() {
    var q by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val model = remember {
        Firebase.ai(backend = GenerativeBackend.googleAI()).generativeModel("gemini-3.8-flash")
    }
    LazyColumn(Modifier.fillMaxSize().padding(20.dp)) {
        item {
            Text("المساعد الذكي", fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text("صيانة، أعطال، قطع، موديلات ونصائح للدراجات النارية.")
            Spacer(Modifier.height(18.dp))
            Card(shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text("أسئلة سريعة", fontWeight = FontWeight.Bold)
                    listOf("الدراجة لا تشتغل، ماذا أفعل؟", "متى أغير زيت المحرك؟", "ما سبب ضعف السحب؟").forEach { x ->
                        Text("• $x", Modifier.padding(top = 10.dp).clickable { q = x })
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), label = { Text("اكتب سؤالك") }, minLines = 3)
            Spacer(Modifier.height(10.dp))
            Button(enabled = q.isNotBlank() && !loading, onClick = {
                loading = true
                answer = ""
                scope.launch {
                    try {
                        val prompt = "أنت مساعد متخصص بالدراجات النارية. أجب بالعربية بوضوح وباختصار، واذكر التحذيرات عندما تكون الصيانة خطرة. سؤال المستخدم: $q"
                        val response = model.generateContent(prompt)
                        answer = response.text ?: "لم يصل رد من النموذج."
                    } catch (e: Exception) {
                        answer = "تعذر الاتصال بالمساعد الآن. افتح Firebase AI Logic وأكمل إعداد Gemini/App Check ثم جرّب مرة أخرى.\n\n${e.localizedMessage ?: "خطأ غير معروف"}"
                    } finally { loading = false }
                }
            }, Modifier.fillMaxWidth()) { Text(if (loading) "جاري التفكير…" else "اسأل المساعد") }
            if (answer.isNotBlank()) {
                Spacer(Modifier.height(14.dp))
                Card { Text(answer, Modifier.padding(18.dp)) }
            }
        }
    }
}

@Composable
fun Account() {
    var wallet by remember { mutableStateOf("") }
    var wallet2 by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    LazyColumn(Modifier.fillMaxSize().padding(20.dp)) {
        item {
            Text("حسابي", fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(20.dp))
            Card { Column(Modifier.padding(20.dp)) { Text("معيض", fontSize = 24.sp, fontWeight = FontWeight.Bold); Text("مالك منصة معيض موتور"); Text("📞 771335364") } }
            Spacer(Modifier.height(16.dp))
            Text("طرق الدفع", fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text("أضف روابط محافظك بشكل اختياري ليظهرها المشتري عند التواصل.", fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(wallet, { wallet = it }, Modifier.fillMaxWidth(), label = { Text("رابط المحفظة 1") })
            OutlinedTextField(wallet2, { wallet2 = it }, Modifier.fillMaxWidth(), label = { Text("رابط المحفظة 2") })
            Spacer(Modifier.height(8.dp))
            Button(onClick = {
                scope.launch {
                    try {
                        if (auth.currentUser == null) auth.signInAnonymously().await()
                        db.collection("settings").document("owner").set(mapOf("phone" to "771335364", "wallet1" to wallet, "wallet2" to wallet2)).await()
                        status = "تم حفظ إعدادات الدفع."
                    } catch (e: Exception) { status = "تعذر الحفظ: ${e.localizedMessage}" }
                }
            }) { Text("حفظ طرق الدفع") }
            if (status.isNotBlank()) Text(status, Modifier.padding(top = 8.dp))
        }
    }
}
